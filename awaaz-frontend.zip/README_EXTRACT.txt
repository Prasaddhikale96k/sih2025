This archive contains the frontend-only files extracted from the provided project.
Backend/server-related files were intentionally removed.
App name strings were replaced with 'awaaz' where found.
Please review and run `npm install` / `npm run dev` in the frontend folder(s).
